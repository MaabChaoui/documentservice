package com.example.document.security;

import com.example.document.util.JwtUtil;
import io.jsonwebtoken.Claims;
import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class JwtAuthFilter implements Filter {

    private final JwtUtil jwtUtil;

    public JwtAuthFilter(JwtUtil jwtUtil) {
        this.jwtUtil = jwtUtil;
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        String authHeader = httpRequest.getHeader("Authorization");

        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            httpResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            httpResponse.getWriter().write("Missing or invalid Authorization header");
            System.out.println("❌ Missing or invalid Authorization header");
            return;
        }

        try {
            String token = authHeader.substring(7);
            System.out.println("🔐 Token received: " + token);

            Claims claims = jwtUtil.extractAllClaims(token);

            UserContext ctx = new UserContext();
            ctx.setEmail(claims.getSubject());
            ctx.setRole((String) claims.get("role"));

            // Safe conversion of departments claim
            List<?> rawDepartments = (List<?>) claims.get("departments");
            List<Integer> departmentIds = new ArrayList<>();
            for (Object obj : rawDepartments) {
                if (obj instanceof Integer) {
                    departmentIds.add((Integer) obj);
                } else {
                    departmentIds.add(Integer.parseInt(obj.toString()));
                }
            }
            ctx.setDepartments(departmentIds);

            UserContext.set(ctx);
            System.out.printf("✅ JWT parsed successfully: %s | Depts: %s%n", ctx.getEmail(), ctx.getDepartments());

        } catch (Exception e) {
            httpResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            httpResponse.getWriter().write("Invalid or expired token");
            System.out.println("❌ Token error: " + e.getMessage());
            return;
        }

        try {
            chain.doFilter(request, response);
        } finally {
            UserContext.clear(); // Always clear context to avoid thread leaks
        }
    }
}
