package com.example.document.controller;

import com.example.document.dto.DocumentRequest;
import com.example.document.model.Document;
import com.example.document.service.DocumentService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/documents")
public class DocumentController {

    private final DocumentService documentService;

    public DocumentController(DocumentService documentService) {
        this.documentService = documentService;
    }

    @PostMapping
    public Document create(@RequestBody DocumentRequest request) {
        return documentService.createDocument(request);
    }

    @GetMapping
    public List<Document> getMyDocs() {
        return documentService.getMyDocuments();
    }
}
